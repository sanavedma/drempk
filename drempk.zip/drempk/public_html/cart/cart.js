var cart = {};

function loadcart() {
    //проверяем есть ли в локалсторедж запись карт
    if (localStorage.getItem('cart')) {
        //если есть - расшифровываю и записываю карт
        cart = JSON.parse(localStorage.getItem('cart'));
        showCart();

    } else {
        emptyCart();
    }
}

function emptyCart() {
    var out = '';
    out += `<div class="title">`;
    out += `<a href="user.php"><img src="../img/ep_arrow-down.svg" alt=""></a>`;
    out += `<h1>Корзина</h1>`;
    out += `</div>`;
    out += `<div class="information">`;
    out += `<h2>Корзина пока пуста</h2>`;
    out += `<p>Перейдите в каталог, чтобы совершить покупки</p>`;
    out += `</div>`;
    out += `<a href="cataloge.html"><button id="design">В каталог</button></a>`;
    out += `</div>`;
    $('.orders').html(out);
}

function showCart() {
    //вывод корзины
    if (!isEmpty(cart)) {
        emptyCart();
    } else {
        $.getJSON('../cart/product.json', function (data) {
            var products = data;
            var out = '';
            var sum = 0;
            var total = 0;
            out += `<div class="title">`;
            out += `<a href="user.php"><img src="../img/ep_arrow-down.svg" alt=""></a>`;
            out += `<h1>Корзина</h1>`;
            out += `</div>`;
            for (var id in cart) {
                out += `<div class="orders-container">`;
                out += `<img src="${products[id].image}" alt="">`;
                out += `<div class="orders-information">`;
                out += `<div class="information-title">`;
                out += `<div>${products[id].name}</div>`;
                out += `<div class="bold">${products[id].price}₽</div>`;
                out += `</div>`;
                out += `<div class="information-title">`;
                out += `<div class="count">`;
                out += `<button data-id="${id}" class="plus">+</button>`;
                out += `${cart[id]}`;
                out += `<button data-id="${id}" class="minus">-</button>`;
                out += `</div>`;
                out += `<div data-id="${id}" class="delite">Удалить</div>`;
                out += `</div>`;
                out += `</div>`;
                out += `</div>`;
                sum = products[id].price * cart[id];
                total += sum;
            }
            out += `<h3>Итого: ${total} ₽</h3>`;
            out += `<button class="design">Оформить заказ</button>`;
            $('.orders').html(out);
            $('.delite').on('click', delProducts);
            $('.plus').on('click', plusProducts);
            $('.minus').on('click', minusProducts);
            $('.design').on('click', sendEmail);
        })
    }
}

function minusProducts() {
    //добавляет товар в корзине
    var id = $(this).attr('data-id');
    if (cart[id] == 1) {
        delete cart[id];
    } else {
        cart[id]--;
    }
    saveCart();
    showCart();
}

function plusProducts() {
    //добавляет товар в корзине
    var id = $(this).attr('data-id');
    cart[id]++;
    saveCart();
    showCart();
}

function delProducts() {
    //удаляем товар из корзины
    var id = $(this).attr('data-id');
    delete cart[id];
    saveCart();
    showCart();
}

function saveCart() {
    //сохранение корзины
    localStorage.setItem('cart', JSON.stringify(cart));
}

function isEmpty(object) {
    //проверка корзины на пустоту
    for (var key in object)
    if (object.hasOwnProperty(key)) return true;
    return false;
}

function sendEmail() {
    // localStorage.clear();

    design();
}

function design() {
    var out = '';
    out += '<div class="title">';
    out += '<a href="user.php"><img src="../img/ep_arrow-down.svg" alt=""></a>';
    out += '<h1>Корзина</h1>';
    out += '</div>';
    out += '<div class="information">';
    out += '<h2>Заказ оформлен</h2>';
    out += '<p>Спасибо за покупку!</p>';
    out += '</div>';
    out += '<a href="cataloge.html"><button id="design">В каталог</button></a>';
    $('.orders').html(out);
}

$(document).ready(function () {
    loadcart();
})
var cart = {}; //корзина
function init() {
    //вычитуем файл 
    var hash = window.location.hash.substring(1);
    console.log(hash);
    $.post (
        "../admin/core.php",
        {
            "action" : "loadSingleProduct", 
            "id" : hash
        },
        productsOut
    )
    $.getJSON("../cart/product.json", productsOut);
}

function productsOut(data) {
    //вывод на страницу продукта
    if (data!=0) {
        data = JSON.parse(data);
        console.log(data);
        out='';
        out += `<div class="title">`;
        out += `<a href="cataloge.html"><img src="../img/ep_arrow-down.svg" alt=""></a>`;
        out += `<h1>${data.name}</h1>`;
        out += `</div>`;
        out += `<div class="data-goods">`;
        out += `<img src="${data.image}" alt="">`;
        out += `<div class="data-goods-inner">`;
        out += `<div class="inner-wrapper">`;
        out += `<div class="inner-item">`;
        out += `<p>Название: </p><p>${data.name}</p></div>`;
        out += `<div class="inner-item">`;
        out += `<p>Дата производства:</p>`;
        out += `<p>${data.age}</p>`;
        out += `</div>`;
        out += `<div class="inner-item">`;
        out += `<p>Страна-производитель: </p>`;
        out += `<p>${data.country}</p>`;
        out += `</div>`;
        out += `<div class="inner-item">`;
        out += `<p>Цвет: </p>`;
        out += `<p>${data.color}</p>`;
        out += `</div>`;
        out += `<div class="inner-item">`;
        out += `<p>Размер (д*ш*в): </p>`;
        out += `<p>${data.size}</p>`;
        out += `</div>`;
        out += `<div class="inner-item">`;
        out += `<p>Описание:</p>`;
        out += `<p>${data.description}</p>`;
        out += `</div>`;
        out += `</div>`;
        out += `</div>`;
        $('.information-goods').html(out);
    } else {
        $('.information-goods').html('Что-то пошло не так :( Такого товара не существует');
    }
}


$(document).ready(function () {
    init();
})
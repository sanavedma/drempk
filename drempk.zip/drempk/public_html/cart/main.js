var cart = {}; //корзина
function init() {
    //вычитуем файл 
    $.post (
        "../admin/core.php",
        {
            "action" : "loadProducts"
        },
        productsOut
    )
    $.getJSON("../cart/product.json", productsOut);
}

function productsOut(data) {
    //вывод на страницу каталога
    data = JSON.parse(data);
    console.log(data);
    out='';
    for (var key in data) {
        out += '<div class="products-inner">';
        out += `<img src="${data[key].image}" alt="">`;
        out += `<a href="product.html#${key}"><p>${data[key].name}</p></a>`;
        out += `<p>${data[key].price} ₽</p>`;
        out += `<button class="add-to-cart" data-id="${key}">В корзину</button>`;
        out += '</div>';
    }
    $('.products').html(out);
    $('.add-to-cart').on('click', addToCart);
}

function addToCart() {
    //добавляем товар в корзину
    var id = $(this).attr('data-id');
    // console.log(id);
    if (cart[id] == undefined) {
        cart[id] = 1; //если в корзине нет товара - делаем 1
    } else {
        cart[id]++; // если такой товар есть увеличиваем на 1
    }
    showMiniCart();
    saveCart();
}

function saveCart() {
    //сохранение корзины
    localStorage.setItem('cart', JSON.stringify(cart));
}

function showMiniCart() {
    //показываю мини корзину
    var out = '';
    for (var key in cart) {
        // out+= key +'--'+ cart[key]+'<br>';
    }
    $('.mini-cart').html(out);
}

function loadcart() {
    //проверяем есть ли в локалсторедж запись карт
    if (localStorage.getItem('cart')) {
        //если есть - расшифровываю и записываю карт
        cart = JSON.parse(localStorage.getItem('cart'));
        showMiniCart();
    }
}

$(document).ready(function () {
    init();
    loadcart();
})
var cart = {};

function loadcart() {
    //проверяем есть ли в локалсторедж запись карт
    if (localStorage.getItem('cart')) {
        //если есть - расшифровываю и записываю карт
        cart = JSON.parse(localStorage.getItem('cart'));
        showCart();

    } else {
        emptyCart();
    }
}

function emptyCart() {
    var out = '';
    out += `<div class="title">`;
    out += `<a href="user.php"><img src="../img/ep_arrow-down.svg" alt=""></a>`;
    out += `<h1>Мои заказы</h1>`;
    out += `</div>`;
    out += `<div class="information">`;
    out += `<h2>Активных заказов пока нет</h2>`;
    out += `<p>Перейдите в каталог, чтобы совершить покупки</p>`;
    out += `</div>`;
    out += `<a href="cataloge.html"><button id="design">В каталог</button></a>`;
    out += `</div>`;
    $('.orders').html(out);
}

function showCart() {
    //вывод заказа
    if (!isEmpty(cart)) {
        emptyCart();
    } else {
        $.getJSON('../cart/product.json', function (data) {
            var products = data;
            var out = '';
            var sum = 0;
            var total = 0;
            out += `<div class="title">`;
            out += `<a href="user.php"><img src="../img/ep_arrow-down.svg" alt=""></a>`;
            out += `<h1>Мои заказы</h1>`;
            out += `</div>`;
            for (var id in cart) {
                sum = products[id].price * cart[id];
                out += `<div class="orders-container">`;
                out += `<img src="${products[id].image}" alt="">`;
                out += `<div class="orders-information">`;
                out += `<div class="information-title">`;
                out += `<div>${products[id].name}</div>`;
                out += `<div class="bold">${sum}₽</div>`;
                out += `</div>`;
                out += `<div class="information-title">`;
                out += `${cart[id]} штук`;
                out += `<div class="bold">Оформлен</div>`;
                out += `</div>`;
                out += `</div>`;
                out += `</div>`;
                
            }
            $('.orders').html(out);
        })
    }
}

function saveCart() {
    //сохранение корзины
    localStorage.setItem('cart', JSON.stringify(cart));
}

function isEmpty(object) {
    //проверка корзины на пустоту
    for (var key in object)
    if (object.hasOwnProperty(key)) return true;
    return false;
}

$(document).ready(function () {
    loadcart();
})
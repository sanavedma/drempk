<?php 
function connect() {
    $connect = mysqli_connect('localhost', 'ck14561_drempk', 'W4N5WUUv', 'ck14561_drempk');

    if (!$connect) {
        die("Connection failed: " . mysqli_connect_error());
    }
    return $connect;
}

function init() {
    //вывожу список товаров
    $conn = connect();
    $sql = "SELECT * FROM product";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0) {
        $out = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $out[$row["id"]] = $row;
        }
        echo json_encode($out);
    } else {
        echo "0 result";
    }

    mysqli_close($conn);
    writeJSON();
}

function writeJSON() {
    //вывожу список товаров
    $conn = connect();
    $sql = "SELECT * FROM `product`";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0) {
        $out = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $out[$row["id"]] = $row;
        }
        $a = file_put_contents('../cart/product.json', json_encode($out));
        echo $a;
    } else {
        echo "0 result";
    }
    mysqli_close($conn);
}

function loadProducts() {
    $conn = connect();
    $sql = "SELECT * FROM `product`";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0) {
        $out = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $out[$row["id"]] = $row;
        }
        echo json_encode($out);

    } else {
        echo "0 result";
    }
    mysqli_close($conn);
}

function loadSingleProduct() {
    $id = $_POST['id'];
    $conn = connect();
    $sql = "SELECT * FROM `product` WHERE id='$id'";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        echo json_encode($row);

    } else {
        echo "0 result";
    }
    mysqli_close($conn);

}

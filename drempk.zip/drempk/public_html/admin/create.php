<?php
    session_start(); 
    require_once ('connect.php'); 
    
    $name = $_POST['name'];
    $age = $_POST['age'];
    $country = $_POST['country'];
    $color = $_POST['color']; 
    $size = $_POST['size']; 
    $description= $_POST['description']; 
    $price = $_POST['price'];

    $path = '../uploads/'.time().$_FILES['image']['name'];
    if(move_uploaded_file($_FILES['image']['tmp_name'], $path)) {
        mysqli_query($connect, "INSERT INTO `product` (`id`, `name`, `age`, `country`, `color`, `size`, `description`, `image`, `price`) VALUES (NULL, '$name', '$age', '$country', '$color', '$size', '$description', '$path', '$price')" );
        $_SESSION['message'] = 'Товар успешно создан'; 
        header('Location: admin.html');  
    } else {
        $_SESSION['message'] = 'Администратор, что-то пошло не так...';
        header('Location: ../html/cataloge.html');
    }
?>
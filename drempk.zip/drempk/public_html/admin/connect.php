<?php
    $connect = mysqli_connect('localhost', 'ck14561_drempk', 'W4N5WUUv', 'ck14561_drempk');

    if (!$connect) {
        die('Error connect to Database');
    }

?>
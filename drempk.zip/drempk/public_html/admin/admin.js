function init() {
    $.post(
        "../admin/core.php",
        {
            "action": "init"
        },
        showProducts
    )
}

function showProducts(data) {
    data = JSON.parse(data);
    console.log(data);
    var out = '<select>';
    out += '<option data-id="0">Новый товар</option>';
    for (const id in data) {
        out += `<option data-id=${data[id]}>${data[id].name}</option>`;
    }
    out += '</select>';
    $('.mini-cart').html(out);
}



$(document).ready(function () {
    init();
})
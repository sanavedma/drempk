<?php 
    session_start(); 

    if ($_SESSION['users']) {
        header('Location: user.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/registration.css">

    <!-- фавиконка -->
    <link type="Image/x-icon" href="../img/фавиконка.svg" rel="icon">

    <!-- основный шрифит -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

    <!-- стилевой шрифт -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Iceland&family=Jost:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <title>DremPK</title>
</head>
<body>
    <!-- шапка -->
    <header>
        <div class="logo">
            <img src="../img/home/logo.svg" alt="">
        </div>
        <nav>
            <a href="../index.html"><button>О нас</button></a>
            <a href="cataloge.html"><button>Каталог</button></a>
            <a href="contact.html"><button>Контакты</button></a>
            <a href="registration.php"><button>Кабинет</button></a>
        </nav>
    </header>

    <main>
        <div class="registration">
            <h1>Регистрация</h1>
            <div class="registration-question">
                У вас уже есть аккаунт?
                <a href="autorization.php">Войти</a>
            </div>
            <form action="../inc/signup.php" method="post">
                <input name="name" type="text" placeholder="Имя">
                <input name="surname" type="text" placeholder="Фамилия">
                <input name="patronymic" type="text" placeholder="Отчество">
                <input name="login" type="text" placeholder="Придумайте логин">
                <input name="email" type="email" placeholder="Почта">
                <input name="password" type="password" placeholder="Придумайте пароль">
                <input name="password_repeat" type="password" placeholder="Повторите пароль">

                <button type="submit">Зарегистрироваться</button>
                <?php
                    if ($_SESSION['message']) {
                        echo $_SESSION['message'];
                    };
                    unset($_SESSION['message']);
                ?>
            </form>
        </div>
    </main>

    <!-- подвал -->
    <footer>
        <div class="logo">
            <img src="../img/home/logo.svg" alt="">
        </div>
        <nav>
            <a href="index.html">О нас </a>
            <a href="html/cataloge.html">Каталог</a>
            <a href="html/contact.html">Контакты</a>
        </nav>
        <div class="anonum">© 2010-2024 DremPK. Все права защищены.</div>
    </footer>
</body>
</html>
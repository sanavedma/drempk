<?php 
    session_start(); 

    if (!$_SESSION['users']) {
        header('Location: autorization.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/user.css">

    <!-- фавиконка -->
    <link type="Image/x-icon" href="../img/фавиконка.svg" rel="icon">

    <!-- основный шрифит -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

    <!-- стилевой шрифт -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Iceland&family=Jost:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">
    <title>DremPK</title>
</head>
<body>
    <!-- шапка -->
    <header>
        <div class="logo">
            <img src="../img/home/logo.svg" alt="">
        </div>
        <nav>
            <a href="../index.html"><button>О нас</button></a>
            <a href="cataloge.html"><button>Каталог</button></a>
            <a href="contact.html"><button>Контакты</button></a>
            <a href="registration.php"><button>Кабинет</button></a>
        </nav>
    </header>

    <main>
        <h1>Личный кабинет</h1>
        <div class="user-container">
            <div class="user-avatar">
                <img src="../img/user/avatar.svg" alt="">
            </div>
            <div class="user-data">
                <p><?= $_SESSION['users']['name'] ?></p>
                <p><?= $_SESSION['users']['surname'] ?></p>
                <p><?= $_SESSION['users']['patronymic'] ?></p>
                <p><?= $_SESSION['users']['login'] ?></p>
                <p><?= $_SESSION['users']['email'] ?></p>
            </div>
            <div class="user-navigation">
                <a href="my-orders.html"><button>Мои заказы</button></a>
                <a href="basket.html"><button>Корзина</button></a>
                <a href="../inc/logout.php"><button id="logout" type="submit">Выйти</button></a> 
            </div>
        </div>
    </main>

    <!-- подвал -->
    <footer>
        <div class="logo">
            <img src="../img/home/logo.svg" alt="">
        </div>
        <nav>
            <a href="index.html">О нас </a>
            <a href="html/cataloge.html">Каталог</a>
            <a href="html/contact.html">Контакты</a>
        </nav>
        <div class="anonum">© 2010-2024 DremPK. Все права защищены.</div>
    </footer>
</body>
</html>
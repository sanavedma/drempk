<?php
    $connect = mysqli_connect('localhost', 'ck14561_drempk', 'W4N5WUUv', 'ck14561_drempk');

    if (!$connect) {
        die('Error connect to Database');
    }
       // $mysql = new mysqli('localhost', 'root', '', 'mesme');
    // $mysql->query("SET NAMES 'utf8'");
    // if($mysql->connect_error) {
    //     echo 'Error Number'.$mysql->connect_errno.'<br>';
    //     echo 'Error: '.$mysql->connect_error;
    // }
    // $mysql->close();
?>
<?php 
    session_start(); 
    require_once ('connect.php'); 
    
    $name = $_POST['name'];
    $surname = $_POST['surname'];
    $patronymic = $_POST['patronymic'];
    $login = $_POST['login']; 
    $email = $_POST['email']; 
    $password= $_POST['password']; 
    $password_repeat = $_POST['password_repeat'];

    if ($name != '' and $surname != '' and $patronymic != '' and $login != '' and $email != '' and $password != '' and $password_repeat != '') {
        if($password === $password_repeat) {
        $password = md5($password);
        mysqli_query($connect, "INSERT INTO `users` (`id`, `name`, `surname`, `patronymic`, `login`, `email`, `password`) VALUES (NULL, '$name', '$surname', '$patronymic', '$login', '$email', '$password')" );
        $_SESSION['message'] = 'Регистрация прошла успешно!'; 
        header('Location:../html/autorization.php');  
    } else {
        $_SESSION['message'] = 'Пароли не совпадают';
        header('Location: ../html/registration.php');
    }
    }
    else {
        $_SESSION['message'] = 'Заполните все поля';
        header('Location: ../html/registration.php');
    }
    